import binascii
import collections
import logging
import struct
import time
import unittest
import flarm.crc

import flarm.firmware

def _pageNumberGenerator(useIV, offset, numberPages):
    if useIV:
        numberPages -= 1
        yield 0xffff
    n = 0
    while n < numberPages:
        yield n + offset
        n += 1

BasicDevInfo = collections.namedtuple(
    "BasicDevInfo", "deviceId flashSize bootSize pageSize EEpromSize osccal")

ExtDevInfo = collections.namedtuple(
    "ExtDevInfo", "PlatformFamily DeviceName PartNumber")

BootloaderErrorMessage = collections.namedtuple("BootloaderErrorMessage", "Error Undefined")

# ----------------------------------------
# API
# ----------------------------------------
class FirmwareRecovery(object):

    '''
    Recovery mode class used to flash the firmware. Recovery mode requires the device to be restarted since we rely on the bootloader.
    We call it recovery because we directly write into the flash memory. To be noted, the bootloader address range can't be written to.

    Base documentation is "FTD-27 FLARM Upgrade Specification".

    The class is expected to be used in conjunction with FLARMFirmwareReader.

    Error handling
    '''

    _ESC_CHAR = b'\\'
    _CMD_START_PAGE = b'b'
    _CMD_FLASH_DONE = b'z'
    _CMD_SET_OFFSET = b'o'

    _PAGE_MAP = dict(Q=32, R=64, S=128, T=256, U=512)
    _ID_MAP = dict(a=b"LX06", b=b"LX06_FR", c=b"LXN-Flarm-IGC", f=b"LXV",
                   g=b"LXV_FM", h=b"LXV-FM-IGC", l=b"OZ06", m=b"OZ-IGC",
                   o=b"TRXFLM", q=b"ET06", r=b"ECW100F-IGC", v=b"FLYTEC",
                   w=b"OEM", x=b"SOMAX", C=b"Flarm04", D=b"Flarm05",
                   E=b"Flarm06", F=b"Flarm-IGC05", G=b"Flarm-IGC06", K=b"flarm2")


    @staticmethod
    def _escape_str(myStr):
        def _gen():
            for ch in bytearray(myStr):
                yield ch
                if ch == ord(FirmwareRecovery._ESC_CHAR):
                    yield ord(FirmwareRecovery._ESC_CHAR)

        return bytearray([ch for ch in _gen()])

    @staticmethod
    def _unescape_str(myStr):
        def _gen():
            try:
                i = iter(bytearray(myStr))
                while True:
                    ch = next(i)
                    if ch == ord(FirmwareRecovery._ESC_CHAR):
                        yield next(i)
                    else:
                        yield ch
            # Due to change in PEP 479.
            except StopIteration:
                return

        return bytearray([ch for ch in _gen()])

    def __init__(self, s):
        self.serial = s

    def syncBootloader(self, timeout):
        '''
        Waits for synchronization with the bootloader.

        To be noted, this method will wait forever for the bootloader's response if none
        is received.
        :return: None
        '''
        logging.info("Waiting for bootloader")
        syncCount = 0
        until = None
        if timeout is not None:
            until = time.time() + timeout
        while True:
            self.serial.write(b'\0')
            if self.serial.inWaiting() > 0:
                c = self.serial.read()
                if c == b'>':
                    syncCount += 1
                else:
                    syncCount = 0
                if syncCount > 3:
                    self.serial.write(b'<')
                    break
            else:
                time.sleep(0.01)
            if until is not None and time.time() > until:
                logging.info("Timed out synchronizing with bootloader")
                return False

        logging.info("Bootloader ready")
        return True

    def _readDiscardRepliesAndMask(self, mask):
        c = self.serial.read()
        while c == b'>':
            c = self.serial.read()
        return chr(ord(c) & mask)

    def readBasicDevInfo(self):
        '''
        Read the device's information after synchronization with the bootloader.
        :return: the retrieved device base information.
        '''
        deviceInfoMasks = [0xff, 0x7f, 0x7f, 0x7f, 0x7f, 0xff]

        return BasicDevInfo(*[self._readDiscardRepliesAndMask(deviceInfoMasks[i]) for i in range(6)])
    
    def readExtendedDevInfo(self):
        '''
        Read the extended device's information which is send by bootloader version >= 1.13 after synchronization with the bootloader.
        For the old bootloader (version < 1.13) bootloader does not send any information which will lead to the serial reading timeout.
        :return: the retrieved device extended information.
        '''        
        list = []
        c = self.serial.read()
        if not c:
            return None
        # '!' is the delimiter in the bootloader version >= 1.14
        # '\n' is the delimiter in the bootloader version == 1.13. This version was programmed in the first batch
        # of AM boards. This version of bootloader is automatically updated to 1.14 by firmware version 6.40 to 6.42.
        while c and c != b'!' and c != b'\n':
            list.append(c)
            c = self.serial.read()
        return dict(e.split(b'=') for e in filter(None,(b''.join(list)).split(b';')))

    @staticmethod
    def _createFrame(pageAddress, data):
        toSend = bytearray()
        toSend.extend(bytearray(struct.pack("<H", pageAddress)))
        toSend.extend(data)
        crc = flarm.crc.xmodem(bytes(toSend))
        toSend.extend(bytearray(struct.pack(">H", crc)))
        return FirmwareRecovery._ESC_CHAR + FirmwareRecovery._CMD_START_PAGE + FirmwareRecovery._escape_str(
            toSend)

    def _sendPage(self, pageAddress, data):
        self.serial.write(FirmwareRecovery._createFrame(pageAddress, data))

    @staticmethod
    def _createSetOffsetFrame(offset):
        toSend = bytearray()
        toSend.extend(bytearray(struct.pack("<I", offset)))
        crc = flarm.crc.xmodem(bytes(toSend))
        toSend.extend(bytearray(struct.pack(">H", crc)))
        return FirmwareRecovery._ESC_CHAR + FirmwareRecovery._CMD_SET_OFFSET + FirmwareRecovery._escape_str(
            toSend)

    def _sendSetOffset(self, offset):
        self.serial.write(FirmwareRecovery._createSetOffsetFrame(offset))

    def _checkTransmittedProperly(self, messages):
        c = self.serial.read()
        if c == b'!':
            return True
        else:
            if c == b'&':
                logging.error(messages.Error)
            else:
                logging.error(messages.Undefined)
            return False

    def _checkPageTransmittedProperly(self, pageNumber):
        blErrorMessage = BootloaderErrorMessage("Flash error on page " + str(pageNumber), "Undefined error on page " + str(pageNumber))
        return self._checkTransmittedProperly(blErrorMessage)

    def _checkSetOffsetTransmittedProperly(self, offset):
        blErrorMessage = BootloaderErrorMessage("Error on setting offset " + str(offset), "Undefined error on setting offset " + str(offset))
        return self._checkTransmittedProperly(blErrorMessage)

    def _sendAndCheck(self, sendFunction, checkFunction, **kwargs):
        retry = 0
        while True:
            sendFunction(*kwargs['sendArgs'])
            if checkFunction(*kwargs['checkArgs']):
                break
            elif retry < 5:
                retry += 1
            else:
                return False
        return True

    def uploadFirmware(self, devInfo, firmwareEntry):
        '''
        Uploads a firmware image
        :param devInfo: the device information, typically returned by readDevInfo.
        :param firmwareEntry: the firmware's entry to be used.
        :return: True on success, False upon failure.
        '''
        pageSize = FirmwareRecovery._PAGE_MAP[devInfo.pageSize]
        if len(firmwareEntry.data) % pageSize != 0:
            logging.error("Length of data must be a multiple of %d" %
                          firmwareEntry.pageSize)
            return False
        #Bootloader is waiting for any character
        self.serial.write(b'f')
        while True:
            c = self.serial.read()
            if c == b'!':
                break

        # Due to protocol of bootloader working on uin16_t for the page number,
        # we have to set the offset if the offset is above uint16_max.
        pageOffset = firmwareEntry.offset // pageSize
        if firmwareEntry.offset > 0xffff:
            args = {'sendArgs': [firmwareEntry.offset], 'checkArgs': [firmwareEntry.offset]}
            if not self._sendAndCheck(self._sendSetOffset, self._checkSetOffsetTransmittedProperly, **args):
                logging.error("Error setting offset even after trying to retransmit offset %d" % firmwareEntry.offset)
            pageOffset = 0
        numberPages = len(firmwareEntry.data) // pageSize
    
        # Construct a vector with page addresses. If this is an Extended Entry, then
        # check whether an initial vector (IV) is used. If yes, the IV is sent first
        # with the (invalid) address of -1 / 0xffff. Note that the IV counts towards
        # numberPages, too
        if isinstance(firmwareEntry, flarm.firmware.StandardEntry):
            generator = _pageNumberGenerator(False, pageOffset, numberPages)
        else:
            generator = _pageNumberGenerator(firmwareEntry.useIV, pageOffset, numberPages)

        chunkNumber = 0
        for pageNumber in generator:
            logging.info("Transmitting: %.2f%%" %
                         (100.0 * chunkNumber / (numberPages - 1)))
            args = {'sendArgs': [pageNumber, firmwareEntry.data[chunkNumber * pageSize: (chunkNumber + 1) * pageSize]], 'checkArgs': [pageNumber]}
            if not self._sendAndCheck(self._sendPage, self._checkPageTransmittedProperly, **args):
                logging.error("Error even after trying to retransmit page %d" % pageNumber)
                return False
            chunkNumber += 1

        self.serial.write(FirmwareRecovery._ESC_CHAR)
        self.serial.write(FirmwareRecovery._CMD_FLASH_DONE)
        self.serial.write(FirmwareRecovery._ESC_CHAR)
        self.serial.write(FirmwareRecovery._CMD_FLASH_DONE)
        return True
