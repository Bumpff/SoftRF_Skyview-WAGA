import struct
import collections
import logging
import flarm.crc

AVR_FLARM = 0
ARM_FLARM = 2

FIRMWARE_MAGIC = 0x23AB

# PowerFLARM, NG entry
ExtendedEntry = collections.namedtuple(
    "ExtendedEntry",
    "deviceDescriptor versionDescriptor extendedInfo offset pageSize useIV reserved data")

# Classic FLARM entry
StandardEntry = collections.namedtuple(
    "StandardEntry", "deviceDescriptor versionDescriptor offset reserved data")

MAGIC_FORMAT = "<H"
ADDRESS_FORMAT = "<I"
ENTRY_FORMAT = "<HIH"
STANDARD_ENTRY_FORMAT = "<32s32sI8s"
EXTENDED_ENTRY_FORMAT = "<32s32s128sIII64s"


# ----------------------------------------
# API
# ----------------------------------------
class FirmwareWriter(object):
    '''
    Write .fw files.
    Signature/ciphering of images must be performed before using this class.
    '''

    def __init__(self):
        self.rawFw = bytearray()

    def _generateHeader(self, entries):
        return struct.pack(MAGIC_FORMAT, FIRMWARE_MAGIC) + struct.pack("<H",
                                                                       len(entries))

    def _generateAddresses(self, offset, rawEntries):
        pos = offset + len(rawEntries) * struct.calcsize(ADDRESS_FORMAT)
        ret = bytes()
        for rawEntry in rawEntries:
            ret += struct.pack(ADDRESS_FORMAT, pos)
            pos += len(rawEntry)
        return ret

    def _generateEntry(self, entryType, entryLength, crc):
        return struct.pack(ENTRY_FORMAT, entryType, entryLength,
                           crc) + bytearray(8)

    def _generateExtendedEntry(self, entry):
        ee = struct.pack(EXTENDED_ENTRY_FORMAT, entry.deviceDescriptor,
                         entry.versionDescriptor,
                         entry.extendedInfo, entry.offset, entry.pageSize,
                         entry.useIV, entry.reserved) + entry.data
        return self._generateEntry(ARM_FLARM, len(ee), flarm.crc.xmodem(bytes(ee))) + ee

    def _generateStandardEntry(self, entry):
        se = struct.pack(STANDARD_ENTRY_FORMAT, entry.deviceDescriptor,
                         entry.versionDescriptor, entry.offset,
                         entry.reserved) + entry.data
        return self._generateEntry(AVR_FLARM, len(se), flarm.crc.xmodem(bytes(se))) + se

    def generateFirmware(self, entries):
        '''
        Creates a .fw image given a set of entries.
        :param entries: list of entries
        :return: the raw firmware image
        '''
        rawEntries = []
        for entry in entries:
            rawEntry = None
            if isinstance(entry, ExtendedEntry):
                rawEntry = self._generateExtendedEntry(entry)
            elif isinstance(entry, StandardEntry):
                rawEntry = self._generateStandardEntry(entry)
            else:
                return False
            rawEntries.append(rawEntry)
        header = self._generateHeader(entries)
        addresses = self._generateAddresses(len(header),rawEntries)
        return header + addresses + bytearray().join(rawEntries)


class FirmwareWriterAddressesHack(FirmwareWriter):
    '''
    Write .fw file like flarmutil written in Java Tool was doing it.

    The difference between FirmwareWriterAddressesHack and FirmwareWriter is that
    the FirmwareWriterAddressesHack reserves in the header of the .fw file more space for the
    address field than needed. In the other words, when we have 1 entry there should be one address
    included in the addresses space, with 2 entries - 2 addresses. In Java implementation situation is,
    e.g. for 1 entry space for 3 addresses is reserved and only one is set (the rest is set to 0).
    The reason why in Java implementation we have such strange formula to calculate addresses space
    is unknown, therefore Urban decided to keep the behaviour for the legacy reason.

    Signature/ciphering of images must be performed before using this class.
    '''
    def _generateAddresses(self, offset, rawEntries):
        endOfAddressesFieldFromBeginning = 8*int((offset + len(rawEntries) * struct.calcsize(ADDRESS_FORMAT))/8) + 8
        pos = endOfAddressesFieldFromBeginning
        ret = bytes()
        for rawEntry in rawEntries:
            ret += struct.pack(ADDRESS_FORMAT, pos)
            pos += len(rawEntry)
        i = ((endOfAddressesFieldFromBeginning - offset)) - len(rawEntries)*struct.calcsize(ADDRESS_FORMAT)
        ret += bytearray(int(i))
        return ret

class FirmwareReader(object):
    '''
    Read .fw files.
    See FTD-27 FLARM Upgrade Specification for more documentation about the
    content of .fw files.

    The raw firmware image must be passed to the constructor.
    '''

    def __init__(self, rawFW):
        self.rawFW = rawFW

    def _checkMagic(self):
        (magic,) = struct.unpack_from(MAGIC_FORMAT, memoryview(self.rawFW), 0)
        return magic == FIRMWARE_MAGIC

    def _retrieveAddresses(self):
        (numberOfEntries,) = struct.unpack_from("<H", memoryview(self.rawFW), 2)
        addresses = [struct.unpack_from(ADDRESS_FORMAT, memoryview(self.rawFW),
                                        4 + i * struct.calcsize(
                                            ADDRESS_FORMAT))[0] for i in
                     range(0, numberOfEntries)]
        return addresses

    def _retrieveEntry(self, address):
        assert (address + struct.calcsize(ENTRY_FORMAT) <= len(self.rawFW))
        return struct.unpack_from(ENTRY_FORMAT, memoryview(self.rawFW), address)

    def _retrieveStandardEntry(self, address, entryLength):
        assert (address + entryLength <= len(self.rawFW))
        return struct.unpack_from(STANDARD_ENTRY_FORMAT, memoryview(self.rawFW),
                                  address) + (
                   self.rawFW[address + 76: address + entryLength],)

    def _retrieveExtendedEntry(self, address, entryLength):
        assert (address + entryLength <= len(self.rawFW))
        return struct.unpack_from(EXTENDED_ENTRY_FORMAT, memoryview(self.rawFW),
                                  address) + (
                   self.rawFW[address + 268: address + entryLength],)

    def retrieveEntries(self):
        '''
        Retrieves all deparsed entries from the .fw image
        :return: the list of entries
        '''
        if self._checkMagic():
            entries = []
            addresses = self._retrieveAddresses()
            for address in addresses:
                (entryType, entryLength, crc) = self._retrieveEntry(address)
                entryAddress = address + 16
                if crc != flarm.crc.xmodem(bytes(
                        self.rawFW[entryAddress: entryAddress + entryLength])):
                    continue
                if entryType == ARM_FLARM:
                    entries.append(
                        ExtendedEntry(*self._retrieveExtendedEntry(entryAddress,
                                                                   entryLength)))
                elif entryType == AVR_FLARM:
                    entries.append(
                        StandardEntry(*self._retrieveStandardEntry(entryAddress,
                                                                   entryLength)))
                else:
                    None
            return entries
        return None

    @staticmethod
    def _getFieldFromExtendedEntry(extEntry, what):
        extInfo = (bytes(extEntry.extendedInfo)).strip(b'\0')
        extInfosDict = dict(e.split(b'=') for e in filter(None, extInfo.split(b';')))
        return extInfosDict[what]

    @staticmethod
    def _isItemInExtendedEntryField(extEntryField, what):
        items = extEntryField.split(b',')
        for item in items:
            if item.lower() == (what.strip(b'\0')).lower():
                return True
        return False

    @staticmethod
    def _extEntryMatches(entry, extDevInfo):
        # standard entry is a classic FLARM entry, no extended information in classic FLARM firmware file
        if isinstance(entry, StandardEntry):
            return True
        # extension entry is non classic FLARM entry
        if isinstance(entry, ExtendedEntry):  # PowerFLARM file entry
            if not extDevInfo:  # Bootloader version < 1.13, only on PowerFLARM devices (they were only manufactured by FLARM Technology Ltd.)
                if FirmwareReader._getFieldFromExtendedEntry(entry, b'DeviceName').lower() == b"PowerFLARM".lower():
                    return True
            else:  # Bootloader version >=1.13 or safe mode update (for each devices)
                # Go through all descriptors in extended field of the firmware file.
                # If the value for the given descriptor is not the one we expect or the descriptor does not exists at all the firmware is not applicable.
                extEntry = FirmwareReader.extendedEntryToDictionary(entry)
                logging.debug('ExtendedEntry: %s', entry.extendedInfo)
                for key in extEntry:
                    # Descriptor not present
                    if not key in extDevInfo.keys():
                        return False
                    # Descriptor value is incorrect
                    if not FirmwareReader._isItemInExtendedEntryField(extEntry[key], extDevInfo[key]):
                        logging.debug("%s %s do not match %s %s", key, extEntry[key], key, extDevInfo[key])
                        return False
                # no restriction or all fields matched
                return True

    @staticmethod
    def extendedEntryToDictionary(entry):
        return dict(e.split(b'=') for e in filter(lambda x: x is not None and b'=' in x, entry.extendedInfo.strip(b'\0').split(b';')))

    @staticmethod
    def platformVersionMatches(entry, platformVersion):
        if entry.deviceDescriptor.strip(b'\0').lower() == platformVersion.lower():
            return True
        return False

    @staticmethod
    def retrieveMatchingEntry(entries, platformVersion, extDevInfo):
        for entry in entries:
            if (FirmwareReader.platformVersionMatches(entry, platformVersion)) and (
            FirmwareReader._extEntryMatches(entry, extDevInfo)):
                return entry
        return None

