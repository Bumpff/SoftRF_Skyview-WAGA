import time
import logging

class TextCommunication(object):
   '''
   Text communication with FLARM devices

   Reference document is "FTD-12 Data port specification".
   To be noted, errors are propagated upwards.
   No timeout checks.
   '''
   FLARM_EOL = b'\r\n'

   def __init__(self, serial):
      '''

      :param serial: the serial port
      :return:
      '''
      self.serial = serial

   def _baudMapping(self, baudrate):
      _BaudMapping = [4800, 9600, 19200, 28800, 38400, 57600, 115200, 230400]
      for i, s in enumerate(_BaudMapping):
         if baudrate == s:
            return i
      return None

   def _discardAll(self):
      while True:
         waiting = self.serial.inWaiting()
         if waiting > 0:
            logging.debug("Ignoring %s" % self.serial.read(waiting))
         else:
            break

   def setBaudrate(self, baudrate):
      '''
      Attempts to set the baudrate on all supported baudrate by text communication.
      :param baudrate:
      :return:
      '''
      for curbaudrate in (4800, 9600, 19200, 28800, 38400, 57600, 115200, 230400):
         logging.info("Setting baudrate %d on %d" % (baudrate, curbaudrate))
         self.serial.baudrate = curbaudrate
         time.sleep(0.2)
         self.transmitSentence("$PFLAC,S,BAUD1," + str(self._baudMapping(baudrate)))
         self._discardAll()
      time.sleep(0.2)
      self.serial.baudrate = baudrate
      self._discardAll()
      self.serial.flushInput()
      self.serial.flushOutput()

   # Have run into issues where all of a sudden we get an issue when communicating with FLARM when using
   # http://stackoverflow.com/questions/16470903/pyserial-2-6-specify-end-of-line-in-readline method with TextIOWrapper.
   # Using something that we know really works.
   def _readline(self, stop_event = None):
      eol = bytearray(TextCommunication.FLARM_EOL)
      leneol = len(eol)
      line = bytearray()
      while True:
         c = self.serial.read(1)
         if c and (stop_event is None or not stop_event.is_set()):
            line += c
            if line[-leneol:] == eol:
               break
         else:
            break
      readLine = bytes(line)
      logging.debug("Read " + str(readLine))
      return readLine

   def transmitSentence(self, data):
      logging.debug("Sent: " + str(data))
      toSend = data + TextCommunication.FLARM_EOL
      bytesSent = self.serial.write(toSend)
      if bytesSent != len(toSend):
         logging.error('Sentence wasn\'t sent [%s]' % data)

   @staticmethod
   def _nmeaCheckSum(data):
      checksum = 0
      for c in data:
         checksum ^= ord(c)
      return checksum

   def sync(self, stop_event = None):
      i = 200

      self._discardAll()

      while i > 0 and (stop_event is None or not stop_event.is_set()):
         self.transmitSentence(b"$PFLAP")
         while True:
            read = self._readline(stop_event)
            if read == b"$PFLAP,A*26" + TextCommunication.FLARM_EOL:
               return True
            if self.serial.inWaiting() == 0:
               logging.debug("No more lines waiting")
               break
         i -= 1
      return False

   def setConfiguration(self, parameter, value, maxTime):
      self.transmitSentence(b"$PFLAC,S," + parameter + b"," + bytes(str(value), 'utf-8'))
      expectedAnswer = b"$PFLAC,A," + parameter
      while True:
         line = self._readline()
         if line.startswith(expectedAnswer.upper()):
            return value
         if time.time() > maxTime:
            return None

   def readConfiguration(self, parameter, maxTime):
      self.transmitSentence(b"$PFLAC,R," + parameter)
      expectedAnswerStart = b"$PFLAC,A," + parameter
      wrongAnswerStart = b"$PFLAC,A,ERROR*41"
      while True:
         line = self._readline()
         if line.startswith(wrongAnswerStart.upper()):
            return None
         elif line.startswith(expectedAnswerStart.upper()):
            # Remove line ending, remove checksum, split
            splittedLine = line.strip()[:-3].split(b',')
            return splittedLine[3]
         if time.time() > maxTime:
            return None
