"""
CRC functionality abstraction module.
Whatever crc functionality provider we use it is encapsulated here.
"""
import crcmod
import six

_crc_xmodem = crcmod.predefined.mkCrcFun('xmodem')


def xmodem(value, crc=None):
    """
    creates a xmodem crc from the given value considering the previous crc value if given.
    """

    # transformation of input data due to interface inconsistencies in crcmod between
    # native (c) and python install.
    #
    # if the crcmod is installed with the python backend we cannot use bytes nor bytearray
    # as input types. Only the python2 b'spamandeggs' bytestring type is valid.
    # the c-native backend however allows for bytes and bytearrays.
    if six.PY2 and not isinstance(value, str) and (isinstance(value, bytes) or isinstance(value, bytearray)):
        value = b''.join([chr(element) for element in value])

    if crc:
        return _crc_xmodem(value, crc=crc)
    return _crc_xmodem(value)
