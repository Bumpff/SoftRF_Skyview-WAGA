import time
import logging

from serialutil.binary_communication import Firmware
from flarm.firmware import FirmwareReader, FirmwareWriter
import flarm.bootloader_communication
import serialutil.common

# ----------------------------------------
# Update functions
# ----------------------------------------
def update_fw_recovery(serial, fileContent, force, timeout = None):
    ''' Send a firmware image using recovery mode. In this mode
        the existing firmware is instantly deleted when the upload starts.
        If the process is interrupted, no valid firmware remains on the device.
        The bootloader is not touched by this.
        :param serial: Serial port, fully initialized
        :param fileContent: Content of .fw file containing the firmware image
        :param force: provided there's on entry in the .fw file, force the update
                      of the firmware, whatever the bootloader returns
        :param timeout: timeout in seconds to synchronize with the bootloader.
                        None will wait forever.
    '''
    #from flarm.bootloader_communication import FirmwareRecovery
    # For some reason, setting timeouts while receiving data leads to dropped
    # characters. We were doing it in readExtendedDevInfo in
    # bootloader_communication.py.
    # I tried several pyserial version, several python versions and they all
    # have the same issue.
    # The default value is higher, but for the bootloader communication,
    # a value of 1 second is reasonable.
    # If we were to use a value higher than 1, it takes more time to synchronize
    # the bootloader.
    serial.timeout = 1

    # Initiate "recovery" bootloader mode and sync with unit.
    # Also retrieve device info packet after handshake
    recovery = flarm.bootloader_communication.FirmwareRecovery(serial)
    if recovery.syncBootloader(timeout):
        basicDevInfo = recovery.readBasicDevInfo()
        extendedDeviceInfo = recovery.readExtendedDevInfo()
        logging.debug("Device information %s", extendedDeviceInfo)
        platformVersion = flarm.bootloader_communication.FirmwareRecovery._ID_MAP[basicDevInfo.deviceId]

        # Now read FW file and find an appropriate image for
        # this device. If it exists, initiate bootloading the binary
        # data.
        entry = searchFirmwareInFwFile(fileContent, platformVersion, extendedDeviceInfo, force)
        if entry is not None:
            return recovery.uploadFirmware(basicDevInfo, entry)
        else:
            logging.error("No firmware entry found for %s and %s" %
                          (platformVersion, extendedDeviceInfo))
            return False


def update_fw_safe(serial, fileContent, platformVersion, binary_baudrate):
    ''' Send a firmware image using safe mode. In this mode
        the existing firmware is not deleted until the device
        has checked a valid new firmware has been fully received.
        Thus, it is not possible to bring the device into an undefined state.
        :param serial: Serial port, fully initialized
        :param fileContent: Content of .fw file containing the firmware image
        :param platformVersion: Name of the entry in the .fw file.
    '''
    # Safe mode currently only implemented for PF and NG devices.
    # Initiate a binary communication and get device info
    textCommunication = serialutil.common.text_communication_initiate(serial)
    if textCommunication is None:
        return False

    # Look for an appropriate image in the FW file.
    reader = FirmwareReader(bytearray(fileContent))
    entries = reader.retrieveEntries()
    logging.info("Found %d entries in firmware" % len(entries))
    for entry in entries:
        logging.info("Checking entry with platform=%s, version=%s extendedInfo=%s" %
                     (entry.deviceDescriptor.strip(b'\0'),
                      entry.versionDescriptor.strip(b'\0'),
                      entry.extendedInfo.strip(b'\0')))
        # Enquires the keys
        if FirmwareReader.platformVersionMatches(entry, platformVersion) and \
                update_fw_firmwareMatches(textCommunication, entry):
            logging.info("Found matching firmware")
            return update_fw_safe_communication(serial, entry, binary_baudrate, None)

    logging.warning("No matching firmware found")

def update_fw_safe_communication(serial, entry, baudrate, progressCallback):
    # Initiate safe mode bootloading: Switch to binary mode, then
    # upload image, finally reset device. The device expects a full
    # .fw file which we construct on the fly, containing only one entry.
    # This operation can obviously also be done "offline".
    communication = serialutil.common.binary_communication_initiation(serial)
    if communication is None:
        return False
    communication.setBaudRate(baudrate)
    return update_fw(communication, entry, progressCallback)

def update_fw_firmwareMatches(textCommunication, entry):
    extEntry = FirmwareReader.extendedEntryToDictionary(entry)
    relevantKeys = (key for key in extEntry if b'ADSBFwVer' != key)
    for key in relevantKeys:
        logging.info("Enquiring property %s" % key)
        value = textCommunication.readConfiguration(key, time.time() + 5)
        logging.info("Retrieved %s" % value)
        if not value:
            return False
        # Descriptor value is incorrect
        if not FirmwareReader._isItemInExtendedEntryField(extEntry[key], value):
            logging.debug("%s %s do not match %s %s", key, extEntry[key], key,
                          value)
            return False
    # no restriction or all fields matched
    return True

def searchFirmwareInFwFile(fileContent, platformVersion, extendedDeviceInfo, force):
    reader = FirmwareReader(bytearray(fileContent))
    entries = reader.retrieveEntries()
    logging.info("Found %d entries in firmware" % len(entries))
    # The force update is only allowed if there is only one image in the firmware file
    if len(entries) == 1 and force:
        return entries[0]
    return reader.retrieveMatchingEntry(entries, platformVersion, extendedDeviceInfo)

def update_fw(communication, entry, progressCallback):
    # Upload image and reset device. The device expects a full
    # .fw file which we construct on the fly, containing only one entry.
    # This operation can obviously also be done "offline".
    updater = Firmware(communication)
    success = updater.uploadFirmware(FirmwareWriter().generateFirmware([entry]), progressCallback)
    if success:
        communication.resetDevice()
    return success

