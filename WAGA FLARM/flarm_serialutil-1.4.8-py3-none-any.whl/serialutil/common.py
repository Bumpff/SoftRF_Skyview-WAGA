import serialutil.binary_communication
import flarm.text_communication

import logging

def text_communication_initiate(serial):
    '''
    Checks we're running in text mode and synchronize with it.
    :param serial: the serial port, fully initialized
    :return: the TextCommunication object if successful, None otherwise
    '''
    textCommunication = flarm.text_communication.TextCommunication(serial)
    if textCommunication.sync():
        logging.info("Text communication synchronized")
        return textCommunication
    else:
        logging.error("Text communication failed to synchronize")
        return None

def binary_communication_initiation(serial):
    '''
    Initiate binary mode and synchronize with it.
    :param serial: the serial port, fully initialized
    :return: the BinaryCommunication object if successful, None otherwise
    '''
    #
    # Switch to binary mode
    binaryCommunication = serialutil.binary_communication.BinaryCommunication(serial, 0x1234)
    binaryCommunication.enterIntoBinaryMode()
    if binaryCommunication.sync():
        logging.info("Binary communication synchronized")
        return binaryCommunication
    else:
        logging.error("Binary communication failed to synchronize")
        return None

