''' FLARM Serial Utility

    This demonstrates the reference implementation for the
    FLARM Binary Protocol library implemented in Python.

    All commands assume that the device is ready to answer to $PFLAX to enter
    maintenance mode.

    It contains:
     . Firmware update
      - Safe mode
      - Recovery mode
     . Licence upload
      - Obstacle database (.ob2 file)
      - Licence file (.lic file)
     . IGC file retrieval
     . Flash image download
     . Resetting the device

'''

import click
import serial
import logging
import time

import serialutil.firmware_update
import serialutil.obstacle_upload
import serialutil.flash_retrieval
import serialutil.igc_readout
import serialutil.binary_communication
import serialutil.serial_replay

from serialutil import __version__

# Set up logger. Uses stdout, hence all output is visible on the
# console. Use this as only user output (i.e. no print)
logger = logging.getLogger()
logger.setLevel(logging.INFO)


# ----------------------------------------
# Cmd-line Script
# ----------------------------------------
# Define and parse cmd-line arguments. If invoked with no arguments,
# prints out a brief help screen.

class Config(object):
    def __init__(self):
        pass


pass_serial_config = click.make_pass_decorator(Config, ensure=True)

DEFAULT_BAUDRATE = 57600

###########################################
# Main Click entry point
###########################################
@click.group(help='FLARM Serial Utility {}. (c)2021 FLARM Technology.'.format(__version__))
@click.version_option(version=__version__)
@click.option('--speed', default=DEFAULT_BAUDRATE,
              help="Baud rate, bits per second, defaults to " +
                   str(DEFAULT_BAUDRATE))
@click.option('--port', default='COM1',
              help="COM port. Typically COMX on Window, /dev/ttyUSB0 on Unix. Default COM1.")
@pass_serial_config
def serial_config(config, speed, port):
    try:
        config.s = serial.Serial(
            port=port,
            baudrate=speed,
            parity=serial.PARITY_NONE,
            stopbits=serial.STOPBITS_ONE,
            bytesize=serial.EIGHTBITS,
            timeout=15
        )
    except OSError as e:
        logging.error("Unable to open serial: %s" % e)
        exit()

@serial_config.command(name='update_fw_recovery')
@click.argument('file', type=click.File('rb'))
@click.option('--force', default=False, is_flag=True)
@click.option('--timeout', type=click.INT, default=None)
@click.option('--rts_dtr_reset', default=False, is_flag=True, help="Attempts to reset the device with RTS/DTR lines."
                                                                   "Tested to work on ESP32 with proper circuitry so far.")
@pass_serial_config
def update_fw_recovery(serial_config, file, force, timeout, rts_dtr_reset):
    """Updates the firmware in recovery mode. One command is run, device must be restarted to enter bootloader mode."""
    try:
        s = serial_config.s
        if rts_dtr_reset:
            logging.info("Resetting device with RTS/DTR lines...")
            s.dtr = False
            s.rts = True
            s.dtr = s.dtr
            time.sleep(0.2)
            s.rts = False
            s.dtr = s.dtr
        serialutil.firmware_update.update_fw_recovery(serial_config.s, file.read(), force, timeout)
    except serial.SerialException as e:
        logging.error("Exception %s" % e)


@serial_config.command(name='update_fw_safe')
@click.argument('file', type=click.File('rb'))
@click.option('--binary_baudrate', type=click.INT, default=DEFAULT_BAUDRATE)
@pass_serial_config
def update_fw_safe(serial_config, file, binary_baudrate):
    """Updates the firmware in safe mode."""

    try:
        serialutil.firmware_update.update_fw_safe(serial_config.s, file.read(),
                                              b"flarm2", binary_baudrate)
    except serial.SerialException as e:
        logging.error("Exception %s" % e)


@serial_config.command(name='upload_obstacle_database')
@click.argument('file', type=click.File('rb'))
@click.option('--binary_baudrate', type=click.INT, default=DEFAULT_BAUDRATE)
@pass_serial_config
def upload_obstacle_database(serial_config, file, binary_baudrate):
    """Uploads an obstacle database."""
    try:
        serialutil.obstacle_upload.uploadObstacleDatabase(serial_config.s,
                                                      file.read(), binary_baudrate)
    except serial.SerialException as e:
        logging.error("Exception %s" % e)


@serial_config.command(name='upload_licence')
@click.argument('file', type=click.File('rb'))
@pass_serial_config
def upload_licence(serial_config, file):
    """Uploads a licence file."""
    try:
        serial_config.s.timeout = 25
        serialutil.obstacle_upload.uploadLicence(serial_config.s, file.read())
    except serial.SerialException as e:
        logging.error("Exception %s" % e)


@serial_config.command(name='flash_download')
@click.argument('file', type=click.File(mode='wb', lazy=False))
@click.option('--binary_baudrate', type=click.INT, default=DEFAULT_BAUDRATE)
@pass_serial_config
def flash_download(serial_config, file, binary_baudrate):
    """Retrieve flash image from a device."""

    try:
        flashContent = serialutil.flash_retrieval.retrieve_flash(serial_config.s, binary_baudrate)
        if flashContent is not None:
            file.write(flashContent)
        else:
            logging.error("Error downloading flash image")
    except serial.SerialException as e:
        logging.error("Exception %s" % e)


@serial_config.command(name='igc_download')
@click.argument('directory', type=click.Path(exists=True))
@click.option('--binary_baudrate', type=click.INT, default=DEFAULT_BAUDRATE)
@pass_serial_config
def igc_download(serial_config, directory, binary_baudrate):
    """IGC files retrieval."""
    try:
        serialutil.igc_readout.retrieve_igc_data(serial_config.s, directory, binary_baudrate)
    except serial.SerialException as e:
        logging.error("Exception %s" % e)


@serial_config.command(name='reset_device')
@pass_serial_config
def reset_device(serial_config):
    """Resets the device."""
    try:
        communication = serialutil.binary_communication.BinaryCommunication(
            serial_config.s, 0x1234)
        communication.enterIntoBinaryMode()
        communication.sync()
        communication.resetDevice()
    except serial.SerialException as e:
        logging.error("Exception %s" % e)

@serial_config.command(name='replay_file_with_timing')
@click.argument('file', type=click.File('r'))
@click.option('--loop', is_flag=True, help='if set the replay file is repeatedly played until the tool is forced to stop.')
@pass_serial_config
def replay_file_with_timing(serial_config, file, loop):
    """Replay a file with timing information on the serial port"""
    try:
        serialutil.serial_replay.replay_file(serial_config.s, file, loop)
    except serial.SerialException as e:
        logging.error("Exception %s" % e)


if __name__ == '__main__':
    serial_config()
