import collections
import logging
import struct
import time
import flarm.crc
from future.builtins import bytes

# ----------------------------------------
# API
# ----------------------------------------
class FRAME_TYPES:
    FRAME_PING = 0x01
    FRAME_SETBAUDRATE = 0x02
    FRAME_FLASHUPLOAD = 0x10
    FRAME_FLASHDOWNLOAD = 0x11
    FRAME_LICENCEUPLOAD = 0x15
    FRAME_OBSTFILEUPLOAD = 0x16
    FRAME_LICENCEFILEUPLOAD = 0x17
    FRAME_SELECTRECORD = 0x20
    FRAME_GETRECORDINFO = 0x21
    FRAME_GETIGCDATA = 0x22
    FRAME_GETFLASHINFO = 0x30
    FRAME_FIRMWAREUPLOAD = 0x40
    FRAME_EXIT = 0x12
    FRAME_ACK = 0xA0
    FRAME_NACK = 0xB7


class BinaryCommunication(object):
    '''
    Binary communication.
    We assume device has already started and is ready to enter maintenance mode.
    To enter binary communication mode:
        . Maintenance mode must be entered
        . Synchronization must be ensured

    Reference document is "FTD-26 FLARM Binary Communication".
    To be noted, errors are propagated upwards.
    No timeout checks.
    '''

    def __init__(self, serial, seq):
        '''

        :param serial: the serial port
        :param seq: the sequence
        :return:
        '''
        self.serial = serial
        self.seq = seq

    _ESC = b'x'
    _START_FRAME = b's'
    _ESC_ESC = b'U'
    _ESC_START = b'1'

    _esc_map = {
        _START_FRAME: _ESC_START,
        _ESC: _ESC_ESC,
    }
    _esc_map_reverse = {v: k for (k, v) in _esc_map.items()}

    @staticmethod
    def _escape_str(myStr):
        def _gen():
            for ch in bytes(myStr):
                if bytes([ch]) in BinaryCommunication._esc_map.keys():
                    yield ord(BinaryCommunication._ESC)
                    yield ord(BinaryCommunication._esc_map[bytes([ch])])
                else:
                    yield ch

        return bytearray([ch for ch in _gen()])

    @staticmethod
    def _unescape_str(myStr):
        def _gen():
            try:
                i = iter(bytes(myStr))
                while True:
                    ch = next(i)
                    if ch == ord(BinaryCommunication._ESC):
                        yield ord(BinaryCommunication._esc_map_reverse[bytes([next(i)])])
                    else:
                        yield ch
            except StopIteration:
                return

        return bytearray([ch for ch in _gen()])

    def _sendFrameAndReceive(self, frame):
        toSend = bytearray(BinaryCommunication._START_FRAME)
        toSend.extend(BinaryCommunication._escape_str(frame))
        self.serial.write(toSend)
        return self._receiveFrame()

    def sendFrameAndReceiveAndRetry(self, frame):
        '''
        Sends a frame to the device.
        Retries a certain amount of time if no ACK is returned.
        :param frame: the frame to send
        :return: The returned ACK frame on success, None on failure.
        '''
        MAX_RETRY = 10
        retry = 0
        retFrame = None
        while retry < MAX_RETRY:
            retFrame = self._sendFrameAndReceive(frame)
            if retFrame is not None and retFrame.type == FRAME_TYPES.FRAME_ACK:
                break
            retry += 1
        if retry >= MAX_RETRY - 1:
            logging.error("Maximum number of retries reached for sendFrame")
            return None
        else:
            self.seq += 1
            if self.seq > 0xFFFF:
                self.seq = 0
            return retFrame

    def _receive(self, buf, length):
        while len(buf) < length:
            c = self.serial.read()
            if c == BinaryCommunication._START_FRAME:
                del buf[:]
                return False
            elif c == BinaryCommunication._ESC:
                nextChar = self.serial.read();
                if nextChar in BinaryCommunication._esc_map_reverse:
                  buf.append(BinaryCommunication._esc_map_reverse[nextChar])
                else:
                    del buf[:]
                    return False
            elif c is not None:
                buf.append(c)
        return True

    def _receiveAndUnescape(self, length):
        buf = []
        if self._receive(buf, length):
            return bytes().join(buf)
        return None

    def _receiveFrame(self):
        while True:
            rawHeader = self._receiveAndUnescape(
                    struct.calcsize(HEADER_FORMAT))
            if rawHeader is None:
                continue
            header = struct.unpack(HEADER_FORMAT, rawHeader)
            payloadLength = header[0] - struct.calcsize(HEADER_FORMAT)
            rawPayload = self._receiveAndUnescape(payloadLength)
            if rawPayload is None:
                continue
            frame = Frame(*header + (rawPayload,))
            if frame.crc != _computeCrc(
                            bytearray(rawHeader) + bytearray(frame.payload)):
                return None
            return frame

    def enterIntoBinaryMode(self):
        '''
        Sends command to enter into binary mode
        :return: None
        '''
        self.serial.write(b"$PFLAX\r\n")
        self.serial.flush()

    def sync(self):
        '''
        Synchronizes with binary mode.
        :return: True upon success, False on failure.
        '''
        NUM_PING = 5
        i = 0
        while i < NUM_PING:
            if self.sendFrameAndReceiveAndRetry(
                    createFramePing(self.seq)) is not None:
                i += 1
            else:
                return False
        return True

    def resetDevice(self):
        '''
        Resets the device
        :return: None if an error occurred or the licence doesn't apply, the ACK frame if successful.
        '''
        logging.info("Resetting device")
        return self.sendFrameAndReceiveAndRetry(createFrameExit(self.seq))

    def _baudMapping(self, baudrate):
        _BaudMapping = [4800, 9600, 19200, 28800, 38400, 57600, 115200, 230400, 460800, 921600]
        for i, s in enumerate(_BaudMapping):
            if baudrate == s:
                return i
        return None

    def setBaudRate(self, baudrate):
        '''
        Sets the baudrate for binary communication. Baud rate is not stored in
        the configuration of the device.
        The serial port's baudrate is also reconfigured if the change is
        successful.
        :return: None if an error occurred, the ACK frame if successful.
        '''

        baudIndex = self._baudMapping(baudrate)
        if baudIndex is None:
            logging.error("Wrong baudrate %d" % (baudrate))
            return None
        frame = self.sendFrameAndReceiveAndRetry(
            createFrameSetBaudRate(self.seq, baudIndex))
        if frame is not None:
            self.serial.baudrate = baudrate
            logging.info("Changed baudrate to %d" % (baudrate))
            time.sleep(0.1)
        else:
            logging.error("Failed to change baudrate")
        return frame


class BinaryCommunicationStub(BinaryCommunication):
    def _receiveFrame(self):
        return Frame(*struct.unpack(HEADER_FORMAT, createFrameAck(self.seq)) + (None,))

class Igc(object):
    '''
    Facility to retrieve IGC formatted flights using binary communication.
    '''

    def __init__(self, binaryComm):
        self.binaryComm = binaryComm

    def selectRecord(self, recordNumber):
        ''' Selects and IGC record.
        :param recordNumber Record number. 0 is the latest, goes up to 39 on PowerFLAM.
        :return If the flight doesn't exist or an error occurred, None is returned. Else, the returned ACK frame is
        returned.
        '''
        logging.info("Selecting flight record %s" % (recordNumber))
        frame = self.binaryComm._sendFrameAndReceive(
                createFrameSelectIgcRecord(self.binaryComm.seq, recordNumber))
        if frame.type != FRAME_TYPES.FRAME_ACK:
            logging.info(
                    "Flight record %d doesn't exist, can't select" % (
                        recordNumber))
            return None
        return frame

    def retrieveIgcInfo(self):
        '''
        Retrieves the IGC info.
        :return None if an error occurred, the raw data if successful.
        '''
        frame = self.binaryComm.sendFrameAndReceiveAndRetry(
                createFrameGetIgcInfo(self.binaryComm.seq))
        if frame is None:
            logging.error("IGC record doesn't exist")
            return None
        return frame.payload[2:]

    def retrieveIgcData(self):
        '''
        Retrieves the IGC replay.
        :return None if an error occurred, the raw data if successful.
        '''
        ret = bytearray()
        while True:
            frame = self.binaryComm.sendFrameAndReceiveAndRetry(
                    createFrameGetIgcData(self.binaryComm.seq))
            if frame is None:
                logging.error("Error retrieving igc readout")
                return None
            (seq, progress) = struct.unpack("<HB", frame.payload[0:3])
            logging.info("Progress %d%%" % (progress))
            length = frame.length
            ret.extend(frame.payload[3:])
            # Any payload ending with 0x1A signifies the end of the playout.
            if frame.payload[-1] == 0x1A:
                del ret[-1]
                break
        return ret


class Fileupload(object):
    '''
    Facility to upload files using binary communication.
    '''

    def __init__(self, binaryComm):
        self.binaryComm = binaryComm

    def uploadFile(self, content, createFunction, progressCallback):
        '''
        Uploads a file
        :param content: The raw file.
        :param createFunction function used to create frame
        :return: ACK frame if successful, None if not.
        '''
        CHUNK_SIZE = 512
        pos = 0
        while pos < len(content):
            until = min(pos + CHUNK_SIZE, len(content))
            frame = self.binaryComm.sendFrameAndReceiveAndRetry(createFunction(
                    self.binaryComm.seq, pos // CHUNK_SIZE, CHUNK_SIZE,
                    content[pos: until]))
            if frame is None:
                logging.error("Error transmitting")
                return frame
            pos += CHUNK_SIZE
            sentPercentage = (100.0 * until / len(content))
            if progressCallback is not None:
                progressCallback.call(sentPercentage)
            logging.info("Transmitting: %.2f%%" % sentPercentage)

        frame = self.binaryComm.sendFrameAndReceiveAndRetry(createFunction(
                self.binaryComm.seq, 0xFFFFFFFF, 0, bytearray()))
        if frame is None:
            logging.error("Error committing")
        return frame


class Licence(object):
    '''
    Facility to upload licence using binary communication.
    '''

    def __init__(self, binaryComm):
        self.binaryComm = binaryComm

    def uploadLicence(self, licenceContent, progressCallback):
        '''
        Uploads the obstacle database.
        :param rawFirmware: The raw obstacle database.
        :param progressCallback: A function to call each time a chunk of data has been sent.
        :return: True if successful, False if not.
        '''
        frame = Fileupload(self.binaryComm).uploadFile(licenceContent,
                                                       createFrameLicenceFileUpload,
                                                       progressCallback)
        if frame is None:
            logging.error("Error validating licence")
            return False
        return True

    def uploadObstacleDatabase(self, rawObstacleDatabase, progressCallback):
        '''
        Uploads the obstacle database.
        :param rawFirmware: The raw obstacle database.
        :param progressCallback: A function to call each time a chunk of data has been sent.
        :return: True if successful, False if not.
        '''
        frame = Fileupload(self.binaryComm).uploadFile(rawObstacleDatabase,
                                                       createFrameObstacleUpload,
                                                       progressCallback)
        if frame is None:
            logging.error("Error validating obstacle database")
            return False
        return True


class Firmware(object):
    '''
    "Safe" mode firmware update. We assume the device has already started and is
    ready to respond to PFL* commands.
    The following steps must be performed:
     . Upload of the firmware. To be noted, the firmware of interest must be extracted
       from the .fw and repackaged into a .fw file containing a single entry.
     . Resets the device
    '''

    def __init__(self, binaryComm):
        self.binaryComm = binaryComm

    def uploadFirmware(self, rawFirmware, progressCallback):
        '''
        Uploads the firmware in "safe" mode.
        :param rawFirmware: The raw firmware for a single entry.
        :param progressCallback: A function to call each time a chunk of data has been sent
        :return: True if successful, False if not.
        '''
        frame = Fileupload(self.binaryComm).uploadFile(rawFirmware,
                                                       createFrameFirmwareUpload,
                                                       progressCallback)
        if frame is None:
            return False
        return True


class Flash(object):
    '''
    Flash download facility.
    '''

    def __init__(self, binaryComm):
        self.binaryComm = binaryComm

    def download(self, totalPageNumber, pageSize):
        '''
        Downloads the internal flash content for troubleshooting purpose.
        :param totalPageNumber: total number of pages to download
        :param pageSize: page size
        :return: Content of the flash on success, None on failure. To be noted, content is proprietary and should be
        sent to FLARM for analysis.
        '''
        ret = bytearray()
        for currentPageNumber in range(0, totalPageNumber):
            logging.info("Flash download %f%%" % (
                100.0 * currentPageNumber / (totalPageNumber - 1)))
            frame = self.binaryComm.sendFrameAndReceiveAndRetry(
                    createFrameFlashDownload(
                            self.binaryComm.seq, currentPageNumber, pageSize))
            if frame is None:
                logging.error("Error downloading dump")
                return None
            ret.extend(frame.payload[2:])
        return ret

    def getFlashInfo(self):
        '''
        Obtains information about the flash (needed for flash dump download).
        :return: Raw flash info result, None on failure.
        '''
        frame = self.binaryComm.sendFrameAndReceiveAndRetry(
                createFrameGetFlashInfo(self.binaryComm.seq))
        if frame is None:
            return None
        return frame.payload[2:]

# ----------------------------------------
# Helper stuff, internal
# ----------------------------------------

HEADER_FORMAT = "<HBHBH"

Frame = collections.namedtuple(
        "Frame", "length, version, seq, type, crc, payload")


def _generateHeader(length, version, seq, type):
    return struct.pack(HEADER_FORMAT, length, version, seq, type, 0)


CRC_FIELD_POS = 6


def _computeCrc(buffer):
    crc = flarm.crc.xmodem(buffer[0:CRC_FIELD_POS], 0)
    crc = flarm.crc.xmodem(buffer[CRC_FIELD_POS + 2:len(buffer)], crc = crc)
    return crc

def _computeAndSetCrc(buffer):
    crc = _computeCrc(buffer)
    buffer[CRC_FIELD_POS: CRC_FIELD_POS + 2] = struct.pack("<H", crc)
    return buffer


def _concatenateHeaderAndBody(version, seq, frameType, body):
    header = _generateHeader(len(body) + struct.calcsize(HEADER_FORMAT),
                             version, seq, frameType)
    return _computeAndSetCrc(bytearray(header + body))


def createFrameFirmwareUpload(seq, pageNumber, pageSize, content):
    body = struct.pack("<IH", pageNumber, pageSize) + content
    return _concatenateHeaderAndBody(3, seq, FRAME_TYPES.FRAME_FIRMWAREUPLOAD,
                                     body)


def createFrameObstacleUpload(seq, pageNumber, pageSize, content):
    body = struct.pack("<IH", pageNumber, pageSize) + content
    return _concatenateHeaderAndBody(3, seq, FRAME_TYPES.FRAME_OBSTFILEUPLOAD,
                                     body)


def createFrameLicenceFileUpload(seq, pageNumber, pageSize, content):
    body = struct.pack("<IH", pageNumber, pageSize) + content
    return _concatenateHeaderAndBody(3, seq,
                                     FRAME_TYPES.FRAME_LICENCEFILEUPLOAD, body)


def createFrameFlashDownload(seq, pageNumber, pageSize):
    body = struct.pack("<IH", pageNumber, pageSize)
    return _concatenateHeaderAndBody(2, seq, FRAME_TYPES.FRAME_FLASHDOWNLOAD,
                                     body)


def createFrameSelectIgcRecord(seq, recordNumber):
    body = struct.pack("<B", recordNumber)
    return _concatenateHeaderAndBody(2, seq, FRAME_TYPES.FRAME_SELECTRECORD,
                                     body)


def createFrameSetBaudRate(seq, baudIndex):
    body = struct.pack("<B", baudIndex)
    return _concatenateHeaderAndBody(1, seq, FRAME_TYPES.FRAME_SETBAUDRATE,
                                     body)


def createFrameGetIgcData(seq):
    return _computeAndSetCrc(
            bytearray(_generateHeader(0, 1, seq, FRAME_TYPES.FRAME_GETIGCDATA)))


def createFrameGetIgcInfo(seq):
    return _computeAndSetCrc(
            bytearray(
                    _generateHeader(0, 1, seq,
                                    FRAME_TYPES.FRAME_GETRECORDINFO)))


def createFrameLicenceUpload(seq, content):
    return _concatenateHeaderAndBody(2, seq, FRAME_TYPES.FRAME_LICENCEUPLOAD,
                                     content)


def createFrameExit(seq):
    return _computeAndSetCrc(
            bytearray(_generateHeader(0, 1, seq, FRAME_TYPES.FRAME_EXIT)))


def createFramePing(seq):
    return _computeAndSetCrc(
            bytearray(_generateHeader(0, 1, seq, FRAME_TYPES.FRAME_PING)))


def createFrameGetFlashInfo(seq):
    return _computeAndSetCrc(
            bytearray(
                    _generateHeader(0, 3, seq,
                                    FRAME_TYPES.FRAME_GETFLASHINFO)))

def createFrameAck(seq):
    return _computeAndSetCrc(bytearray(
                    _generateHeader(0, 1, seq,
                                    FRAME_TYPES.FRAME_ACK)))
