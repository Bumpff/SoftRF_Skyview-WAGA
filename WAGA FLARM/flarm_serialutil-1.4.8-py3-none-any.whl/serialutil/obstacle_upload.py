from serialutil.binary_communication import Licence
from serialutil.common import *

def uploadObstacleDatabase(serial, obstacleDatabaseContent, binary_baudrate):
    '''
    Uploads an obstacle database
    :param serial: Serial port, fully initialized
    :param obstacleDatabaseContent: The content of the obstacle database file
    :param binary_baudrate: The binary baudrate to use in binary communication mode
    :return: True on success, False on failure
    '''
    if text_communication_initiate(serial) is None:
        return False
    communication = binary_communication_initiation(serial)
    if communication is None:
        return False
    communication.setBaudRate(binary_baudrate)
    success = Licence(communication).uploadObstacleDatabase(
        bytearray(obstacleDatabaseContent), None)
    communication.resetDevice()
    return success


def uploadLicence(serial, licenceContent):
    '''
    Uploads a licence file
    :param serial: Serial port, fully initialized
    :param licenceContent: The content of the licence file
    :return: True on success, False on failure
    '''
    if text_communication_initiate(serial) is None:
        return False
    communication = binary_communication_initiation(serial)
    if communication is None:
        return False
    success = Licence(communication).uploadLicence(bytearray(licenceContent), None)
    communication.resetDevice()
    return success
