import collections
from serialutil.binary_communication import Flash
from serialutil.common import *

FlashInfo = collections.namedtuple(
        "FlashInfo", "pageSize totalNumberPages")


def retrieve_flash(serial, binary_baudrate):
    '''
    Retrieve flash image from a device.
    Assumes device is ready to enter binary mode.

    :param serial: Serial port, fully initialized
    :param binary_baudrate: The binary baudrate to use in binary communication mode
    :return: the retrieved obfuscated content
    '''
    if text_communication_initiate(serial) is None:
        return False
    binaryCommunication = binary_communication_initiation(serial)
    if binaryCommunication is None:
        return False
    binaryCommunication.setBaudRate(binary_baudrate)
    flash = Flash(binaryCommunication)
    flashInfo = FlashInfo(*flash.getFlashInfo().strip(b'\0').split(b"|"))
    content = flash.download(int(flashInfo.totalNumberPages),
                             int(flashInfo.pageSize))
    binaryCommunication.resetDevice()
    return content
