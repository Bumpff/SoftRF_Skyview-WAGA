''' Main file to run app as package, i.e. 

    python -m <package>

    This is useful if the entry_point option in setup.py cannot be used, or multiple
    virtualenvs conflict.
'''
import os
import sys

if __package__ == '':
    # This trick stolen from pip wheel:
    # After wheel install, __main__.py is in same directory as cli.py.
    # Hence, need to get the path of __main__.py, strip one directory, add to path.
    # This way the folder containing cli.py  can be imported as package, hence
    # __name__ is set, hence relative imports will work as expected.
    path = os.path.dirname(os.path.dirname(__file__))
    sys.path.insert(0, path)

# "../" now in sys.path; import serialutil properly and go on with usual business
from serialutil import cli
cli.serial_config()
