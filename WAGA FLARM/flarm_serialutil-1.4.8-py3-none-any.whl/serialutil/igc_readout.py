import collections
import os
from serialutil.binary_communication import Igc
from serialutil.common import *

IgcInfo = collections.namedtuple(
        "IgcInfo",
        "suggestedFileName startDate startTime duration pilotName competitionId competitionClass")


def retrieve_igc_data(serial, directory, binary_baudrate):
    '''
    IGC files retrieval from device using binary communication.
    Files are stored with their suggested name in the current directory.
    :param serial: Serial port, fully initialized
    :return: None
    '''
    if text_communication_initiate(serial) is None:
        return False
    binaryCommuncation = binary_communication_initiation(serial)
    if binaryCommuncation is None:
        return False
    binaryCommuncation.setBaudRate(binary_baudrate)
    igc = Igc(binaryCommuncation)

    i = 0
    while True:
        frame = igc.selectRecord(i)
        i = i + 1
        if frame is not None:
            igcInfoFields = igc.retrieveIgcInfo().split(b"|")
            igcInfo = IgcInfo(*igcInfoFields)
            with open(os.path.join(directory, igcInfo.suggestedFileName.decode('utf8')),
                      'wb') as igcFile:
                igcData = igc.retrieveIgcData()
                logging.info("Writing to %s" % igcInfo.suggestedFileName)
                igcFile.write(igcData)
        else:
            break
    binaryCommuncation.resetDevice()
    return True