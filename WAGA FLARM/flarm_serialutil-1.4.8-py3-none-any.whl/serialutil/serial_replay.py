import re
import time


def _wait_until(delta):
    now = time.time()
    future = now + delta
    while time.time() < future:
        time.sleep(delta / 1000.0)


def replay_file(serial, file, loop):
    """
    Replays a file with timing information. This is typically useful for
    display testing.
    Format of the file must have a timestamp in milliseconds in every line.
    If not, the line is ignored.
    The timing is reproduced. Reproduction of the timing is obviously
    not extremely precise and can depend on the configure baudrate.
    :param serial: Serial port, fully initialized
    :param file: The file to replay
    :param loop: Replay file in a loop
    :return: None
    """
    
    previous_time_stamp = 0.0

    while True:
        for line in [data for data in file]:
            match = re.search('^(\d+)\s(.+)', line)
            if match is not None:
                current_time_stamp = float(match.group(1))
                if previous_time_stamp > 0:
                    _wait_until((current_time_stamp - previous_time_stamp) / 1000.0)
                value = '{}\r\n'.format(match.group(2))
                print(value, end='')
                serial.write(value.encode())
                previous_time_stamp = current_time_stamp
        if not loop:
            break
